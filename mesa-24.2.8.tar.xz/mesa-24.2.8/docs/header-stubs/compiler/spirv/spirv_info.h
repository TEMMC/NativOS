struct spirv_capabilities {};
